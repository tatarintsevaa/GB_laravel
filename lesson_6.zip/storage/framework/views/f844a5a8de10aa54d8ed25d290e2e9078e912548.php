<?php $__env->startSection('title', 'Создание новости'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo e(Breadcrumbs::render('create')); ?>

        <h3 class="title">
            Добавить новость
        </h3>
        <div class="card-body">
            <form enctype="multipart/form-data" method="POST" action="<?php echo e(route('admin.news.create')); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-group row">
                    <label for="FormControlSelectTitle" class="col-md-4 col-form-label text-md-right">
                        Выбор категории
                    </label>
                    <div class="col-md-6">
                        <select class="form-control" id="FormControlSelectTitle" name="category_id">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option <?php if($category->id == old('category_id')): ?> selected <?php endif; ?>
                                value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>

                <div class="form-group row">
                    <label for="title" class="col-md-4 col-form-label text-md-right">Заголовок</label>

                    <div class="col-md-6">
                        <input id="title" type="text" class="form-control" name="title" autofocus
                               value="<?php echo e(old('title')); ?>">
                    </div>
                </div>

                <div class="form-group row">
                    <label for="text" class="col-md-4 col-form-label text-md-right">Текст</label>

                    <div class="col-md-6">
                        <textarea id="text" class="form-control" name="text" rows="3"
                                  autofocus><?php echo e(old('text')); ?></textarea>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="image" class="col-md-4 col-form-label text-md-right">
                        Загрузить изображение
                    </label>
                    <div class="col-md-6">
                        <input type="file" name="image" id="image">
                    </div>

                </div>
                <div class="form-group row">
                    <div class="col-md-6 offset-md-4">
                        <div class="form-check">
                            <input <?php if(old('isPrivate') === "1"): ?> checked <?php endif; ?>  id="newsPrivate" name="isPrivate"
                                   type="checkbox" value="1" class="form-check-input">

                            <label for="newsPrivate">Приватная</label>
                        </div>
                    </div>
                </div>
                <div class="form-group row mb-0">
                    <div class="col-md-8 offset-md-4">
                        <button type="submit" class="btn btn-dark">
                            Опубликовать
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/laravel_5.8/resources/views/admin/news/create.blade.php ENDPATH**/ ?>