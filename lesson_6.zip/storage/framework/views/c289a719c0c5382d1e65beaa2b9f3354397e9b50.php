<?php $__env->startSection('title', 'Категории'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo e(Breadcrumbs::render('categories')); ?>

        <ul class="nav flex-column">
            <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <li class="nav-item">
                    <a class="nav-link text-dark" href="<?php echo e(route('news.category.show', ['name' => $category->slug])); ?>">
                        <?php echo e($category->name); ?>

                    </a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                Нет категорий новостей
            <?php endif; ?>
        </ul>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/laravel_5.8/resources/views/news/newsCategories.blade.php ENDPATH**/ ?>