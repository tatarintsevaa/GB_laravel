<?php $__env->startSection('title'); ?>
    ##parent-placeholder-3c6de1b7dd91465d437ef415f94f36afc1fbc8a8##<?php echo e($news->title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if($news): ?>
        <div class="container">
            <?php echo e(Breadcrumbs::render('one', $news)); ?>

            <?php if(!$news->isPrivate): ?>
                <h1 class="title">
                    <?php echo e($news->title); ?>

                </h1>
                <img src="<?php echo e($news->image ?? 'https://via.placeholder.com/300x150'); ?>"
                     class="img-fluid" alt="image">
                <p><?php echo e($news->text); ?></p>
            <?php else: ?>
                <div class="alert alert-info" role="alert">
                    Новость приватная. Зарегистрируйтесь для просмоотра
                </div>
            <?php endif; ?>
        </div>
    <?php else: ?>
        <div class="container">Такой новости нет</div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/laravel_5.8/resources/views/news/newsOne.blade.php ENDPATH**/ ?>