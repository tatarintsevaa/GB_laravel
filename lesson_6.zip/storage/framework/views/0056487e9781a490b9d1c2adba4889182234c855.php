<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo e(Breadcrumbs::render('admin')); ?>

        <h2 class="title">Админка</h2>
        <ul class="nav flex-column">
            <li class="nav-item"><a class="nav-link text-dark" href="<?php echo e(route('admin.news.create')); ?>">Создать новость</a></li>
            <li class="nav-item"><a class="nav-link text-dark" href="<?php echo e(route('admin.news.download')); ?>">Скачать новости</a></li>
        </ul>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/laravel_5.8/resources/views/admin/index.blade.php ENDPATH**/ ?>