<?php
    use Illuminate\Support\Str;
?>



<?php $__env->startSection('title'); ?>
    ##parent-placeholder-3c6de1b7dd91465d437ef415f94f36afc1fbc8a8##Новости<?php if(isset($category)): ?> - <?php echo e($category); ?><?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php if(isset($category)): ?>
            <?php echo e(Breadcrumbs::render('category', $category)); ?>

        <?php else: ?>
            <?php echo e(Breadcrumbs::render('news')); ?>

        <?php endif; ?>
        <h3 class="title">Новости <?php if(isset($category)): ?>категории <?php echo e($category); ?> <?php endif; ?></h3>
        <div class="row row-cols-1 row-cols-md-2">
            <?php $__empty_1 = true; $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-md-6 mb-4">
                    <div class="card">
                        <div class="row no-gutters">
                            <div class="col-4">
                                <div class="card-image">
                                    <img src="<?php echo e($item->image ?? 'https://via.placeholder.com/150'); ?>"
                                         class="card-img img-fluid" alt="image">
                                </div>
                            </div>
                            <div class="col-8">
                                <div class="card-body">
                                    <h5 class="card-title"><?php echo e($item->title); ?></h5>
                                    <p class="card-text"><?php echo e(Str::limit($item->text, 150)); ?></p>
                                </div>
                            </div>

                        </div>
                        <div class="card-footer bg-white">
                            <?php if($item->isPrivate): ?>
                                <a class="btn btn-secondary disabled"
                                   href="<?php echo e(route('news.show', ['id' => $item->id])); ?>"
                                   role="button" tabindex="-1" aria-disabled="true">
                                    Подробнее &raquo;
                                </a>
                            <?php else: ?>
                                <a class="btn btn-secondary" href="<?php echo e(route('news.show', ['id' => $item->id])); ?>"
                                   role="button">
                                    Подробнее &raquo;
                                </a>
                            <?php endif; ?>
                            <span class="card-links">
                            <div>
                              <i class="far fa-eye"></i>
                                <small class="text-muted">0</small>
                            </div>
                            <div>
                                <i class="far fa-comment-dots"></i>
                                <small class="text-muted">0</small>
                            </div>

                        </span>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p>Новостей нет</p>
            <?php endif; ?>
        </div>
        <nav class="news-pagination">
            <?php echo e($news->onEachSide(1)->links()); ?>

        </nav>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/laravel_5.8/resources/views/news/news.blade.php ENDPATH**/ ?>