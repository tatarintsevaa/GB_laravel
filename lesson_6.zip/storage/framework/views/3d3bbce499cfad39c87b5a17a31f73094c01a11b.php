<ul class="navbar-nav mr-auto">
    <li class="nav-item">
        
        <a class="nav-link <?php echo e(request()->routeIs('home')?'active':''); ?>" href="<?php echo e(route('home')); ?>">Главная</a>
    </li>
    <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle"
           href="#"
           id="navbarDropdownNewsCategories" role="button"
           data-toggle="dropdown"
           aria-haspopup="true" aria-expanded="false">Новости</a>

        <div class="dropdown-menu" aria-labelledby="navbarDropdownNewsCategories">
            
            <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <a class="dropdown-item " href="<?php echo e(route('news.category.show', ['name' => $category->slug])); ?>">
                    <?php echo e($category->name); ?>

                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                Нет категорий новостей
            <?php endif; ?>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="<?php echo e(route('news.index')); ?>">Все новости</a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="<?php echo e(route('news.category.index')); ?>">Категории новостей</a>
        </div>
    </li>
    <?php if(true): ?> 
    <?php echo $__env->make('admin.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
</ul>
<?php /**PATH /home/vagrant/code/laravel_5.8/resources/views/menu.blade.php ENDPATH**/ ?>