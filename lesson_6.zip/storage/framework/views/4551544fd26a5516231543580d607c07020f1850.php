<?php $__env->startSection('title', 'Редактирование новостей'); ?>


<?php $__env->startSection('content'); ?>
    <div class="container">
        
        <h3 class="title">
            Редактирование новостей
        </h3>

        <div class="row">
            <div class="col-1">id</div>
            <div class="col-8">title</div>
            <div class="col-1">edit</div>
            <div class="col-1">del</div>
        </div>
        <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row">
                <div class="col-1 mb-4"><?php echo e($item->id); ?></div>
                <div class="col-8"><?php echo e($item->title); ?></div>
                <div class="col-1"><a href="" class="btn btn-dark"><i class="fas fa-edit"></i></a></div>
                <div class="col-1"><a href="" class="btn btn-danger"><i class="fas fa-trash-alt"></i></a></div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/laravel_5.8/resources/views/admin/news/edit.blade.php ENDPATH**/ ?>