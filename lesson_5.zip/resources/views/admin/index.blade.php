@extends('layouts.index')

@section('content')
    <div class="container">
        {{ Breadcrumbs::render('admin') }}
        <h2 class="title">Админка</h2>
    </div>
@endsection

