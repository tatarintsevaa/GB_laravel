<?php
    use Illuminate\Support\Str;
?>


<?php $__env->startSection('title', 'Главная'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo e(Breadcrumbs::render('home')); ?>

        <h3 class="title">Список ТОП новостей</h3>
        <!-- тут будем выводить свежие  новостей из базы -->
        <div class="row news-box">
            <?php if(empty($lastNews)): ?>
                <div class="col-12 justify-content-center">Новостей нет</div>
            <?php else: ?>
                <div class="col-md-8">
                    <div class="card bg-white text-dark">
                        <img src="<?php echo e($lastNews->image ?? 'https://via.placeholder.com/500x300'); ?>"
                             class="card-img" alt="image">
                        <div class="card-img-overlay">
                            <h5 class="card-title"><?php echo e($lastNews->title); ?></h5>
                            <p class="card-text"><?php echo e(Str::limit($lastNews->text, 100)); ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <?php $__empty_1 = true; $__currentLoopData = $lustNewsList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <h2><?php echo e($item->title); ?></h2>
                        <p><?php echo e(Str::limit($item->text, 150)); ?></p>
                        <p>
                            <?php if($item->is_private): ?>
                                <a class="btn btn-secondary disabled" href="<?php echo e(route('news.show', ['id' => $item->id])); ?>"
                                   role="button" tabindex="-1" aria-disabled="true">
                                    Подробнее &raquo;
                                </a>
                            <?php else: ?>
                                <a class="btn btn-secondary" href="<?php echo e(route('news.show', ['id' => $item->id])); ?>"
                                   role="button">
                                    Подробнее &raquo;
                                </a>
                            <?php endif; ?>
                        </p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        Новостей нет
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/laravel_5.8/resources/views/index.blade.php ENDPATH**/ ?>