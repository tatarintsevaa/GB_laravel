<?php $__env->startSection('content'); ?>
    <?php if($news): ?>
        <div class="container">
            <h1 class="title">
                <?php echo e($news['title']); ?>

            </h1>
            <p><?php echo e($news['text']); ?></p>
        </div>
    <?php else: ?>
        <div class="container">Такой новости нет</div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/laravel_5.8/resources/views/news/newsOne.blade.php ENDPATH**/ ?>