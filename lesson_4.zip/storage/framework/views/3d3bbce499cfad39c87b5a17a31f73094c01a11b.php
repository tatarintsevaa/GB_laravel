<ul class="navbar-nav mr-auto">
    <li class="nav-item">
        
        <?php if(url()->current() == route('home')): ?>
            <a class="nav-link active" href="<?php echo e(route('home')); ?>">Главная</a>
        <?php else: ?>
            <a class="nav-link" href="<?php echo e(route('home')); ?>">Главная</a>
        <?php endif; ?>
    </li>
    <li class="nav-item">
            <?php if(url()->current() == route('news')): ?>
                <a class="nav-link active" href="<?php echo e(route('news')); ?>">Новости</a>
            <?php else: ?>
                <a class="nav-link " href="<?php echo e(route('news')); ?>">Новости</a>
            <?php endif; ?>
        </li>
    <li class="nav-item dropdown">
        <?php if(url()->current() == route('categories')): ?>
            <a class="nav-link dropdown-toggle active" href="<?php echo e(route('categories')); ?>" id="navbarDropdownNewsCategories" role="button"
               data-toggle="dropdown"
               aria-haspopup="true" aria-expanded="false">Новости по категориям</a>
        <?php else: ?>
            <a class="nav-link dropdown-toggle" href="<?php echo e(route('categories')); ?>" id="navbarDropdownNewsCategories" role="button"
               data-toggle="dropdown"
               aria-haspopup="true" aria-expanded="false">Новости по категориям</a>
        <?php endif; ?>
            <div class="dropdown-menu" aria-labelledby="navbarDropdownNewsCategories">
                
                <?php $__empty_1 = true; $__currentLoopData = \App\Category::getCategories(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?> 
                    <a class="dropdown-item " href="<?php echo e(route('newsByCategories', ['name' => $category['slug']])); ?>">
                        <?php echo e($category['name']); ?>

                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    Нет категорий новостей
                <?php endif; ?>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="<?php echo e(route('categories')); ?>">Категории новостей</a>
            </div>
    </li>
    <?php if(true): ?> 
        <?php echo $__env->make('admin.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
</ul>



























<?php /**PATH /home/vagrant/code/laravel_5.8/resources/views/menu.blade.php ENDPATH**/ ?>