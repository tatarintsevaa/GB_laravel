<?php $__env->startSection('content'); ?>
    <div class="container">
        <h3 class="title">Новости</h3>
        <!-- тут будем выводить топ 6 новостей из базы -->
        <div class="row news-box">
            <?php $__empty_1 = true; $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-md-4">
                    <h2><?php echo e($item['title']); ?></h2>
                    <p><?php echo e($item['text']); ?></p>
                    <p>
                        <a class="btn btn-secondary" href="<?php echo e(route('newsOne', ['id' => $item['id']])); ?>" role="button">
                            Подробнее &raquo;
                        </a>
                    </p>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p>Новостей нет</p>
            <?php endif; ?>
        </div>

    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/laravel_5.8/resources/views/news/news.blade.php ENDPATH**/ ?>